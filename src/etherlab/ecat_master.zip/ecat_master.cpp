

/*
 * POSIX Real Time Example
 * using a single pthread as RT thread
 */

#include <limits.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <iostream>
#include <unistd.h>
#include <math.h>

#include <time.h>
#include <sys/stat.h>
#include "rt_log.h"
#include <libgen.h>

#include "ecat_master.h"
#include "ecat_slave.h"
#include "ecat_task.h"

//uint: us
#define LOOP_PERIOD 1000

// EtherCAT
static ec_master_t *master = NULL;
static ec_master_state_t master_state = {};

static ec_domain_t *domain1 = NULL;
static ec_domain_state_t domain1_state = {};

static uint8_t *domain1_pd = NULL;

slaves_t slaves;


uint32_t loop_counter = 0;
uint16_t min_time_us = LOOP_PERIOD;
uint16_t max_time_us = LOOP_PERIOD;
uint16_t last_time_us = 0;
static float x,y,z;

static inline void tsnorm(struct timespec *ts)
{
    while (ts->tv_nsec >= 1000000000)
    {
        ts->tv_nsec -= 1000000000;
        ts->tv_sec++;
    }
}

void rt_check_domain_state(void)
{
    ec_domain_state_t ds;

    ecrt_domain_state(domain1, &ds);

    if (ds.working_counter != domain1_state.working_counter)
    {
        RT_PRINT("Domain1: WC" + std::to_string(ds.working_counter));
    }

    if (ds.wc_state != domain1_state.wc_state)
    {
        RT_PRINT("Domain1: State " + std::to_string(ds.wc_state));
    }
    domain1_state = ds;
}

/****************************************************************************/
void rt_check_master_state(void)
{
    ec_master_state_t ms;

    ecrt_master_state(master, &ms);

    if (ms.slaves_responding != master_state.slaves_responding)
    {
        RT_PRINT(std::to_string(ms.slaves_responding) + " slave(s).");
        master_state.slaves_responding = ms.slaves_responding;
    }

    if (ms.al_states != master_state.al_states)
    {
        RT_PRINT("ms AL states: " + std::to_string(ms.al_states));
        RT_PRINT("master_state AL states: " + std::to_string(master_state.al_states));
        master_state.al_states = ms.al_states;
    }

    if (ms.link_up != master_state.link_up)
    {
        RT_PRINT("AL states: " + std::to_string(ms.al_states));
        master_state.link_up = ms.link_up;
    }
}


void *thread_func(void *data)
{
    struct timespec systime;
    struct timespec lasttime = {0, 0};
    struct timespec looptime;
    static uint32_t counter_rtlog = 0;
    sleep(1);

    if (clock_gettime(CLOCK_REALTIME, &looptime) == -1)
    {
        std::cout<< "clock_gettime error !!!" <<std::endl;
        goto out_loop;
    }

    while (1)
    {
        looptime.tv_nsec += 1000*LOOP_PERIOD;
        tsnorm(&looptime);
        clock_nanosleep(CLOCK_REALTIME, TIMER_ABSTIME, &looptime, NULL);

        if(++counter_rtlog >= 20)
        {
            RT_MSGSND;            
            snd_msg.msg_text.clear();
            counter_rtlog = 0;
        }


        {
            // receive EtherCAT frames
            ecrt_master_receive(master);
            ecrt_domain_process(domain1);

            //
            rt_check_domain_state();
            rt_check_master_state();

            static int is_link = 0;
            if(master_state.al_states == 0x08) is_link = 1;


            if(is_link)
            {
                ControlTask(domain1_pd, slaves);

                if(master_state.al_states != 0x08)
                {
                    std::cout << "error" << std::endl;

                    break;
                }

//                RT_PRINT("min_time_us: " + std::to_string(min_time_us));
//                RT_PRINT("max_time_us: " + std::to_string(max_time_us));
            }



            //time test
            {
                #if(1)
                {
                    for(uint32_t i=0; i<10; i++)
                    {
                        x = tan(i);
                        y = atan(i);
                        z += x*y;
                    }
                }
                #endif


                loop_counter++;
                if (clock_gettime(CLOCK_REALTIME, &systime) == -1)
                {
                    std::cout<< "clock_gettime error !!!" <<std::endl;
                    goto out_loop;
                }

                {
                    static int i=0;
                    if(i++ < 5000) last_time_us = min_time_us;
                    else last_time_us = 1000000*(systime.tv_sec - lasttime.tv_sec) + (systime.tv_nsec - lasttime.tv_nsec)/1000;
                    min_time_us = min_time_us > last_time_us?   last_time_us:min_time_us;
                    max_time_us = max_time_us < last_time_us?   last_time_us:max_time_us;
                    lasttime = systime;
                }
            }

            //RT log test
            if(0)
            {
                static uint32_t i = 0;
                if(++i >= 100)
                {
                    i=0;
                    std::string log = "I am a RT log, loop counter: " + std::to_string(loop_counter) + ".  loop timer(us): " + std::to_string(last_time_us);
                    RT_PRINT(log);
                }
            }


            //distribute clock
            #if 1
            {
                ecrt_master_application_time(master, 1000000000*((uint64_t)systime.tv_sec) + systime.tv_nsec);
                //ecrt_master_application_time(master, systime.tv_nsec);
                ecrt_master_sync_reference_clock(master);
                ecrt_master_sync_slave_clocks(master);
            }
            #endif

            // send process data
            ecrt_domain_queue(domain1);
            ecrt_master_send(master);            
        }
    }
out_loop:
        return NULL;
}


int EcatMasterInit(void)
{
//            LOG(INFO) <<"Requesting master..."<<std::endl;
    master = ecrt_request_master(0);
    if (!master)
    {
//                LOG(ERROR) << "ecrt_request_master error" <<std::endl;
        return -1;
    }

//            LOG(INFO) <<"ecrt_master_create_domain..."<<std::endl;
    domain1 = ecrt_master_create_domain(master);
    if (!domain1)
    {
//                LOG(ERROR) << "ecrt_master_create_domain error" << std::endl;
        return -1;
    }

//            LOG(INFO) <<"Creating slave configurations..."<<std::endl;


    #ifdef SHIDIAN_Pos_0
        slaves.ShiDian_0.Init(master,SHIDIAN_Pos_0);
    #endif

    #ifdef SYCKIN_Pos_0
        slaves.SycKin_0.Init(master, SYCKIN_Pos_0);
    #endif

    #ifdef MOTOR_Pos_0
        slaves.motor_0.Init(master, MOTOR_Pos_0);
    #endif

    #ifdef IMU_Pos_0
        slaves.imu_0.Init(master, IMU_Pos_0);
    #endif

    #ifdef IMU_Pos_1
        slaves.imu_1.Init(master, IMU_Pos_1);
    #endif

    #ifdef IMU_Pos_2
        slaves.imu_2.Init(master, IMU_Pos_2);
    #endif

    #ifdef IMU_Pos_3
        slaves.imu_3.Init(master, IMU_Pos_3);
    #endif

    #ifdef IMU_Pos_4
        slaves.imu_4.Init(master, IMU_Pos_4);
    #endif

    #ifdef WMIO_Pos_0
        slaves.wmio_0.Init(master, WMIO_Pos_0);
    #endif

    #ifdef WMADC_Pos_0
        slaves.wmadc_0.Init(master, WMADC_Pos_0);
    #endif





//            if (ecrt_domain_reg_pdo_entry_list(domain1, domain1_regs))
//            if (ecrt_domain_reg_pdo_entry_list(domain1, &EcatSlave::domain_regs[0]))
     if (ecrt_domain_reg_pdo_entry_list(domain1, EcatSlave::domain_regs.data()))
    {
//                LOG(ERROR) << "PDO entry registration failed!" << std::endl;
        return -1;
    }

    #ifdef MOTOR_Pos_0
         ecrt_slave_config_dc(slaves.motor_0.sc_motor, 0x0300, 1000000, 440000, 0, 0);
    #endif

    #ifdef WMIO_Pos_0
        ecrt_slave_config_dc(slaves.wmio_0.sc_io, 0x0300, 1000000, 440000, 0, 0);
    #endif

    #ifdef WMADC_Pos_0
        ecrt_slave_config_dc(slaves.wmadc_0.sc, 0x0300, 1000000, 440000, 0, 0);
    #endif

    #ifdef SYCKIN_Pos_0
        ecrt_slave_config_dc(slaves.SycKin_0.sc, 0x0300, 500000, 220000, 0, 0);
    #endif
    #ifdef SHIDIAN_Pos_0
//        ecrt_slave_config_dc(slaves.ShiDian_0.sc, 0x0300, 500000, 220000, 0, 0);
    #endif


//            LOG(INFO) <<"Activating master..."<<std::endl;
    if (ecrt_master_activate(master))
    {
//                LOG(ERROR) << "ecrt_master_activate failed!" << std::endl;
        return -1;
    }

//            LOG(INFO) <<"get domain data pointer..."<<std::endl;
    if (!(domain1_pd = ecrt_domain_data(domain1)))
    {
//                LOG(ERROR) << "Failed to get domain data pointer" << std::endl;
        return -1;
    }


    ec_master_info_t *master_info;
    if(0 != ecrt_master(master, master_info))
    {
        std::cout<< "ecrt_master error!!!!!!!!!!!!!!!!!!!!!! " << std::endl;
        return -1;
    }
    else
    {
        std::cout<< "slave_count" << master_info->slave_count << std::endl;
    }
}

int mainaa(int argc, char* argv[])
{
    chdir(dirname(argv[0])); //设置当前目录为应用程序所在的目录。
    struct sched_param param;
    pthread_attr_t attr;
    pthread_t thread;
    int ret;

    /* Lock memory */
    if(mlockall(MCL_CURRENT|MCL_FUTURE) == -1) {
            printf("mlockall failed: %m\n");
            exit(-2);
    }


    EcatMasterInit();

    /* Initialize pthread attributes (default values) */
    ret = pthread_attr_init(&attr);
    if (ret) {
            printf("init pthread attributes failed\n");
            goto out;
    }

    /* Set a specific stack size  */
    ret = pthread_attr_setstacksize(&attr, PTHREAD_STACK_MIN);
    if (ret) {
        printf("pthread setstacksize failed\n");
        goto out;
    }

    /* Set scheduler policy and priority of pthread */
    ret = pthread_attr_setschedpolicy(&attr, SCHED_FIFO);
    if (ret) {
            printf("pthread setschedpolicy failed\n");
            goto out;
    }
    param.sched_priority = 90;
    ret = pthread_attr_setschedparam(&attr, &param);
    if (ret) {
            printf("pthread setschedparam failed\n");
            goto out;
    }
    /* Use scheduling parameters of attr */
    ret = pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
    if (ret) {
            printf("pthread setinheritsched failed\n");
            goto out;
    }



    /* Create a pthread with specified attributes */
    ret = pthread_create(&thread, &attr, thread_func, NULL);
    if (ret) {
            printf("create pthread failed\n");
            goto out;
    }
    ret = pthread_detach(thread);
    if (ret)    printf("join pthread failed: %m\n");


    //RT_PRINT
    {
        param.sched_priority = 80;
        ret = pthread_attr_setschedparam(&attr, &param);
        if (ret) {
                printf("pthread setschedparam failed\n");
                goto out;
        }
        /* Use scheduling parameters of attr */
        ret = pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
        if (ret) {
                printf("pthread setinheritsched failed\n");
                goto out;
        }

        /* Create a pthread with specified attributes */
        ret = pthread_create(&thread, &attr, RTLogThread, NULL);
        if (ret) {
                printf("create pthread failed\n");
                goto out;
        }
        ret = pthread_detach(thread);
        if (ret)    printf("join pthread failed: %m\n");
    }

    //RT_PRINT_Vector
    {
        param.sched_priority = 78;
        ret = pthread_attr_setschedparam(&attr, &param);
        if (ret) {
                printf("pthread setschedparam failed\n");
                goto out;
        }
        /* Use scheduling parameters of attr */
        ret = pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
        if (ret) {
                printf("pthread setinheritsched failed\n");
                goto out;
        }

        /* Create a pthread with specified attributes */
        ret = pthread_create(&thread, &attr, RTPrintThread_Vector, NULL);
        if (ret) {
                printf("create pthread failed\n");
                goto out;
        }
        ret = pthread_detach(thread);
        if (ret)    printf("join pthread failed: %m\n");
    }

    while (1)
    {
        sleep(1);
        std::cout<< "cycle times: " << std::dec << loop_counter \
                 << "    last_time_us: " << std::dec << last_time_us\
                 << "    min_time_us: " << std::dec << min_time_us \
                 << "    max_time_us: " << std::dec << max_time_us << std::endl;
        std::cout<< "z: " << z << std::endl;

        if(0)
        {
            RT_PRINT("cycle times: " + std::to_string(loop_counter));
            RT_PRINT("last_time_us: " + std::to_string(last_time_us));
            RT_PRINT("min_time_us: " + std::to_string(min_time_us));
            RT_PRINT("max_time_us: " + std::to_string(max_time_us));


            #ifdef SYCKIN_Pos_0
            slaves.SycKin_0.DataPlay();
            #endif

            #ifdef IMU_Pos_0
            slaves.imu_0.DataPlay();
            #endif

            #ifdef IMU_Pos_1
            slaves.imu_1.DataPlay();
            #endif

            #ifdef WMIO_Pos_0
            slaves.wmio_0.DataPlay();
            #endif

            #ifdef MOTOR_Pos_0
            slaves.motor_0.Display();
            #endif
        }
        #ifdef IMU_Pos_0
            slaves.imu_0.DataPlay();
        #endif

        #ifdef MOTOR_Pos_0
        slaves.motor_0.Display();
        #endif

        #ifdef IMU_Pos_1
            slaves.imu_1.DataPlay();
        #endif

        #ifdef IMU_Pos_2
            slaves.imu_2.DataPlay();
        #endif

        #ifdef IMU_Pos_3
            slaves.imu_3.DataPlay();
        #endif

        #ifdef IMU_Pos_4
            slaves.imu_4.DataPlay();
        #endif

        #ifdef WMIO_Pos_0
            slaves.wmio_0.DataPlay();
        #endif

        std::cout<< std::endl;
        std::cout<< std::endl;
        std::cout<< std::endl;

        #ifdef WMADC_Pos_0
            slaves.wmadc_0.DataPlay();
        #endif


        std::cout<< std::endl;



//        RT_PRINT("AL states: " + std::to_string(ms.al_states));

//        std::string log = "I am a RT log, loop counter: " + std::to_string(loop_counter);
//        logdata.push_back(log);

    }

    std::cout <<"End of Program"<<std::endl;
    ecrt_release_master(master);
out:
    return ret;
}
